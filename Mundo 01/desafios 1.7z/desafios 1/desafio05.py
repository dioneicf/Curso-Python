num = int(input('Digite um número: '))
print('O número digitado foi {} e seu antecessor é o número {} e seu sucessor é o número {}'.format(num, num-1, num+1))