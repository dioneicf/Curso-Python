from math import trunc

num = float(input('Digite um número: '))
print('O número digitado foi {} e sua porção inteira é {}'.format(num, trunc(num)))