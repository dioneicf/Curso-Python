cel = float(input('Digite o valor em graus celcius: '))
fah = ((9 * cel) / 5) + 32
print('Temperatura em celcius {:.2f} e temperatura em Fahrenheit {:.2f}'.format(cel, fah))


