nome=input('\033[35mQual é o seu nome? ')
print('\033[34mSeja bem-vindo Senhor(a) {}'.format(nome))
