n1 = int(input('\033[1;35mDigite o primeiro número: '))
n2 = int(input('\033[1;35mDigite o segundo número: '))
print('\033[1;36mA soma vale {}'.format(n1+n2))