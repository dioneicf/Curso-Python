
from math import sin, cos, tan, radians

an = float(input('Digite o valor do ângulo: '))
print('Valor do Seno = {} Valor do Cosseno = {} Valor da Tangente = {}'.format((sin(radians(an))), (cos(radians(an))), (tan(radians(an)))))